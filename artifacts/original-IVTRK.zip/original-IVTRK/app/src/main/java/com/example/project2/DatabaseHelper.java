package com.example.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Handles the SQLite database for users and inventory items.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ivtrk.db";
    private static final int DATABASE_VERSION = 1;

    public static final String USER_TABLE = "users";
    public static final String INVENTORY_TABLE = "inventory";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the database tables the first time the app runs.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE " + USER_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)";

        String createInventoryTable = "CREATE TABLE " + INVENTORY_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT, " +
                "quantity INTEGER, " +
                "details TEXT)";

        db.execSQL(createUserTable);
        db.execSQL(createInventoryTable);
    }

    // Rebuilds tables if the database version changes.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE);
        onCreate(db);
    }

    // Adds a new user account.
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert(USER_TABLE, null, values);
        return result != -1;
    }

    // Checks login information against the user table.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USER_TABLE + " WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        boolean found = cursor.getCount() > 0;
        cursor.close();

        return found;
    }

    // Adds a new inventory item.
    public boolean addInventoryItem(String itemName, int quantity, String details) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("details", details);

        long result = db.insert(INVENTORY_TABLE, null, values);
        return result != -1;
    }

    // Reads all inventory items.
    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + INVENTORY_TABLE + " ORDER BY item_name ASC",
                null
        );
    }

    // Updates the quantity of one inventory item.
    public boolean updateQuantity(int id, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        int result = db.update(
                INVENTORY_TABLE,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Deletes one inventory item.
    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                INVENTORY_TABLE,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}