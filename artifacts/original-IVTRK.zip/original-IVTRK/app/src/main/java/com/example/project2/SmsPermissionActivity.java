package com.example.project2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Handles SMS permission choice before the user enters the inventory screen.
public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText phoneNumberEditText;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        preferences = getSharedPreferences("sms_settings", MODE_PRIVATE);

        Button allowSmsButton = findViewById(R.id.allowSmsButton);
        Button denySmsButton = findViewById(R.id.denySmsButton);

        allowSmsButton.setOnClickListener(v -> requestSmsPermission());
        denySmsButton.setOnClickListener(v -> continueWithoutSms());
    }

    // Requests permission to send SMS alerts.
    private void requestSmsPermission() {
        String phoneNumber = phoneNumberEditText.getText().toString().trim();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Enter a phone number or continue without alerts.", Toast.LENGTH_SHORT).show();
            return;
        }

        preferences.edit()
                .putString("phone_number", phoneNumber)
                .apply();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            preferences.edit()
                    .putBoolean("sms_enabled", true)
                    .apply();

            openInventoryScreen();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    // Continues to the inventory screen without SMS alerts.
    private void continueWithoutSms() {
        preferences.edit()
                .putBoolean("sms_enabled", false)
                .putString("phone_number", "")
                .apply();

        openInventoryScreen();
    }

    // Handles the user's SMS permission response.
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                preferences.edit()
                        .putBoolean("sms_enabled", true)
                        .apply();

                Toast.makeText(this, "SMS alerts enabled.", Toast.LENGTH_SHORT).show();
            } else {
                preferences.edit()
                        .putBoolean("sms_enabled", false)
                        .apply();

                Toast.makeText(this, "SMS denied. App will continue without alerts.", Toast.LENGTH_SHORT).show();
            }

            openInventoryScreen();
        }
    }

    private void openInventoryScreen() {
        Intent intent = new Intent(SmsPermissionActivity.this, InventoryActivity.class);
        startActivity(intent);
    }
}