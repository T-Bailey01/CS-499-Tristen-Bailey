package com.example.project2;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

// Inventory screen for adding, viewing, updating, and deleting items.
public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private EditText itemDetailsEditText;
    private TableLayout inventoryTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        itemDetailsEditText = findViewById(R.id.itemDetailsEditText);
        inventoryTable = findViewById(R.id.inventoryTable);

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(v -> addItem());

        loadInventoryTable();
    }

    // Adds a new item to the inventory database.
    private void addItem() {
        String itemName = itemNameEditText.getText().toString().trim();
        String quantityText = itemQuantityEditText.getText().toString().trim();
        String details = itemDetailsEditText.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Enter an item name and quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean added = databaseHelper.addInventoryItem(itemName, quantity, details);

        if (added) {
            Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();

            itemNameEditText.setText("");
            itemQuantityEditText.setText("");
            itemDetailsEditText.setText("");

            if (quantity == 0) {
                sendLowInventorySms(itemName);
            }

            loadInventoryTable();
        } else {
            Toast.makeText(this, "Item could not be added.", Toast.LENGTH_SHORT).show();
        }
    }

    // Loads database items into the table.
    private void loadInventoryTable() {
        inventoryTable.removeAllViews();
        addHeaderRow();

        Cursor cursor = databaseHelper.getAllInventoryItems();

        if (cursor.getCount() == 0) {
            TableRow emptyRow = new TableRow(this);
            TextView emptyText = makeCell("No inventory items yet.", 260);
            emptyRow.addView(emptyText);
            inventoryTable.addView(emptyRow);
            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            String status;

            if (quantity == 0) {
                status = "Out";
            } else if (quantity <= 10) {
                status = "Low";
            } else {
                status = "In";
            }

            TableRow row = new TableRow(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView itemCell = makeCell(itemName, 120);
            TextView quantityCell = makeCell(String.valueOf(quantity), 80);
            TextView statusCell = makeCell(status, 90);

            Button decreaseButton = makeSmallButton("-");
            decreaseButton.setOnClickListener(v -> changeQuantity(id, itemName, quantity - 1));

            Button increaseButton = makeSmallButton("+");
            increaseButton.setOnClickListener(v -> changeQuantity(id, itemName, quantity + 1));

            Button deleteButton = makeSmallButton("Del");
            deleteButton.setOnClickListener(v -> deleteItem(id));

            row.addView(itemCell);
            row.addView(quantityCell);
            row.addView(statusCell);
            row.addView(decreaseButton);
            row.addView(increaseButton);
            row.addView(deleteButton);

            inventoryTable.addView(row);
        }

        cursor.close();
    }

    // Adds the table headers.
    private void addHeaderRow() {
        TableRow headerRow = new TableRow(this);

        headerRow.addView(makeHeaderCell("Item", 120));
        headerRow.addView(makeHeaderCell("Qty", 80));
        headerRow.addView(makeHeaderCell("Status", 90));
        headerRow.addView(makeHeaderCell("-", 70));
        headerRow.addView(makeHeaderCell("+", 70));
        headerRow.addView(makeHeaderCell("Del", 80));

        inventoryTable.addView(headerRow);
    }

    // Updates the quantity of an item.
    private void changeQuantity(int id, String itemName, int newQuantity) {
        if (newQuantity < 0) {
            Toast.makeText(this, "Quantity cannot be below zero.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = databaseHelper.updateQuantity(id, newQuantity);

        if (updated) {
            if (newQuantity == 0) {
                sendLowInventorySms(itemName);
            }

            loadInventoryTable();
        } else {
            Toast.makeText(this, "Quantity could not be updated.", Toast.LENGTH_SHORT).show();
        }
    }

    // Deletes an item from the database.
    private void deleteItem(int id) {
        boolean deleted = databaseHelper.deleteInventoryItem(id);

        if (deleted) {
            Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
            loadInventoryTable();
        } else {
            Toast.makeText(this, "Item could not be deleted.", Toast.LENGTH_SHORT).show();
        }
    }

    // Sends a low inventory SMS if the user allowed SMS alerts.
    private void sendLowInventorySms(String itemName) {
        SharedPreferences preferences = getSharedPreferences("sms_settings", MODE_PRIVATE);
        boolean smsEnabled = preferences.getBoolean("sms_enabled", false);
        String phoneNumber = preferences.getString("phone_number", "");

        if (!smsEnabled || phoneNumber.isEmpty()) {
            Toast.makeText(this, itemName + " is out of stock. SMS alerts are off.", Toast.LENGTH_LONG).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "IVTRK Alert: " + itemName + " has reached 0 and may need to be restocked.",
                    null,
                    null
            );

            Toast.makeText(this, "SMS alert sent for " + itemName + ".", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, itemName + " is out of stock. SMS permission was not granted.", Toast.LENGTH_LONG).show();
        }
    }

    // Creates aable cell with a fixed width.
    private TextView makeCell(String text, int width) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setWidth(width);
        cell.setPadding(6, 8, 6, 8);
        cell.setGravity(Gravity.CENTER);
        cell.setTextSize(14);
        return cell;
    }

    // Creates a bold header cell.
    private TextView makeHeaderCell(String text, int width) {
        TextView cell = makeCell(text, width);
        cell.setTypeface(null, Typeface.BOLD);
        cell.setTextColor(0xFF1F3A5F);
        return cell;
    }

    private Button makeSmallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(11);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(2, 2, 2, 2);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                70,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(3, 3, 3, 3);
        button.setLayoutParams(params);

        return button;
    }
}