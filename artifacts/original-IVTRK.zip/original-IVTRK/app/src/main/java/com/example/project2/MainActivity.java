package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Login screen for IVTRK.
public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(v -> createAccount());
    }

    // Checks the entered username and password against the database.
    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean validLogin = databaseHelper.checkUser(username, password);

        if (validLogin) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Login failed. Create an account if you are new.", Toast.LENGTH_SHORT).show();
        }
    }

    // Saves a new username and password to the database.
    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean added = databaseHelper.addUser(username, password);

        if (added) {
            Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "That username already exists.", Toast.LENGTH_SHORT).show();
        }
    }
}