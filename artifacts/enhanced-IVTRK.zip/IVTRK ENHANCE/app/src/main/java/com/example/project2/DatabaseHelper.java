package com.example.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

// Handles the SQLite database for users, inventory, and inventory history.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ivtrk.db";

    // Version 3 adds the username to inventory history records.
    private static final int DATABASE_VERSION = 3;

    public static final String USER_TABLE = "users";
    public static final String INVENTORY_TABLE = "inventory";
    public static final String TRANSACTION_TABLE = "inventory_transactions";

    public DatabaseHelper(Context context) {
        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    // Turns on foreign key support for the SQLite database.
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);

        db.setForeignKeyConstraintsEnabled(true);
    }

    // Creates all database tables on a new installation.
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUserTable =
                "CREATE TABLE " + USER_TABLE + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE, " +
                        "password TEXT)";

        String createInventoryTable =
                "CREATE TABLE " + INVENTORY_TABLE + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "item_name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL DEFAULT 0, " +
                        "details TEXT)";

        db.execSQL(createUserTable);
        db.execSQL(createInventoryTable);

        createTransactionTable(db);
    }

    // Upgrades the database without deleting existing users or inventory.
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {

        // Version 2 added inventory history.
        if (oldVersion < 2) {
            createTransactionTable(db);
        }

        // Version 3 adds the username to existing history records.
        if (oldVersion < 3) {

            db.execSQL(
                    "ALTER TABLE "
                            + TRANSACTION_TABLE
                            + " ADD COLUMN username TEXT NOT NULL DEFAULT 'Unknown'"
            );
        }
    }

    // Creates the table used to keep inventory history.
    private void createTransactionTable(
            SQLiteDatabase db
    ) {

        String createTransactionTable =
                "CREATE TABLE IF NOT EXISTS "
                        + TRANSACTION_TABLE
                        + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "inventory_id INTEGER, " +
                        "item_name TEXT NOT NULL, " +
                        "quantity_change INTEGER NOT NULL, " +
                        "resulting_quantity INTEGER NOT NULL, " +
                        "transaction_type TEXT NOT NULL, " +
                        "username TEXT NOT NULL DEFAULT 'Unknown', " +
                        "timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                        "FOREIGN KEY(inventory_id) REFERENCES "
                        + INVENTORY_TABLE
                        + "(id) ON DELETE SET NULL" +
                        ")";

        db.execSQL(createTransactionTable);

        // Helps SQLite find history for an inventory item faster.
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_transaction_inventory_id "
                        + "ON "
                        + TRANSACTION_TABLE
                        + "(inventory_id)"
        );

        // Helps when displaying the newest transactions first.
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_transaction_timestamp "
                        + "ON "
                        + TRANSACTION_TABLE
                        + "(timestamp)"
        );

        // Helps if transaction history is filtered by username later.
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_transaction_username "
                        + "ON "
                        + TRANSACTION_TABLE
                        + "(username)"
        );
    }

    // Adds a new user account.
    public boolean addUser(
            String username,
            String password
    ) {

        SQLiteDatabase db =
                this.getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                "username",
                username
        );

        values.put(
                "password",
                password
        );

        long result =
                db.insert(
                        USER_TABLE,
                        null,
                        values
                );

        return result != -1;
    }

    // Checks login information against the user table.
    public boolean checkUser(
            String username,
            String password
    ) {

        SQLiteDatabase db =
                this.getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT id FROM "
                                + USER_TABLE
                                + " WHERE username = ? AND password = ?",
                        new String[]{
                                username,
                                password
                        }
                );

        boolean found =
                cursor.getCount() > 0;

        cursor.close();

        return found;
    }

    // Adds a new inventory item and records who created it.
    public boolean addInventoryItem(
            String itemName,
            int quantity,
            String details,
            String username
    ) {

        SQLiteDatabase db =
                this.getWritableDatabase();

        db.beginTransaction();

        try {

            ContentValues values =
                    new ContentValues();

            values.put(
                    "item_name",
                    itemName
            );

            values.put(
                    "quantity",
                    quantity
            );

            values.put(
                    "details",
                    details
            );

            long itemId =
                    db.insert(
                            INVENTORY_TABLE,
                            null,
                            values
                    );

            if (itemId == -1) {
                return false;
            }

            boolean historyAdded =
                    addInventoryTransaction(
                            db,
                            (int) itemId,
                            itemName,
                            quantity,
                            quantity,
                            "ADD",
                            username
                    );

            if (!historyAdded) {
                return false;
            }

            db.setTransactionSuccessful();

            return true;

        } finally {

            db.endTransaction();
        }
    }

    // Reads all inventory items and turns them into InventoryItem objects.
    public List<InventoryItem> getAllInventoryItems() {

        List<InventoryItem> inventoryItems =
                new ArrayList<>();

        SQLiteDatabase db =
                this.getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT * FROM "
                                + INVENTORY_TABLE
                                + " ORDER BY item_name ASC",
                        null
                );

        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "id"
                            )
                    );

            String itemName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "item_name"
                            )
                    );

            int quantity =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "quantity"
                            )
                    );

            String details =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "details"
                            )
                    );

            InventoryItem item =
                    new InventoryItem(
                            id,
                            itemName,
                            quantity,
                            details
                    );

            inventoryItems.add(item);
        }

        cursor.close();

        return inventoryItems;
    }

    // Updates an item's quantity and records who made the change.
    public boolean updateQuantity(
            int id,
            int newQuantity,
            String username
    ) {

        SQLiteDatabase db =
                this.getWritableDatabase();

        db.beginTransaction();

        Cursor cursor = null;

        try {

            cursor =
                    db.rawQuery(
                            "SELECT item_name, quantity FROM "
                                    + INVENTORY_TABLE
                                    + " WHERE id = ?",
                            new String[]{
                                    String.valueOf(id)
                            }
                    );

            if (!cursor.moveToFirst()) {
                return false;
            }

            String itemName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "item_name"
                            )
                    );

            int oldQuantity =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "quantity"
                            )
                    );

            int quantityChange =
                    newQuantity - oldQuantity;

            // Nothing changed, so there is nothing new to record.
            if (quantityChange == 0) {

                db.setTransactionSuccessful();

                return true;
            }

            String transactionType;

            if (quantityChange > 0) {
                transactionType = "INCREASE";
            } else {
                transactionType = "DECREASE";
            }

            ContentValues values =
                    new ContentValues();

            values.put(
                    "quantity",
                    newQuantity
            );

            int result =
                    db.update(
                            INVENTORY_TABLE,
                            values,
                            "id = ?",
                            new String[]{
                                    String.valueOf(id)
                            }
                    );

            if (result <= 0) {
                return false;
            }

            boolean historyAdded =
                    addInventoryTransaction(
                            db,
                            id,
                            itemName,
                            quantityChange,
                            newQuantity,
                            transactionType,
                            username
                    );

            if (!historyAdded) {
                return false;
            }

            db.setTransactionSuccessful();

            return true;

        } finally {

            if (cursor != null) {
                cursor.close();
            }

            db.endTransaction();
        }
    }

    // Deletes an inventory item but keeps who performed the deletion.
    public boolean deleteInventoryItem(
            int id,
            String username
    ) {

        SQLiteDatabase db =
                this.getWritableDatabase();

        db.beginTransaction();

        Cursor cursor = null;

        try {

            cursor =
                    db.rawQuery(
                            "SELECT item_name, quantity FROM "
                                    + INVENTORY_TABLE
                                    + " WHERE id = ?",
                            new String[]{
                                    String.valueOf(id)
                            }
                    );

            if (!cursor.moveToFirst()) {
                return false;
            }

            String itemName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "item_name"
                            )
                    );

            int currentQuantity =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "quantity"
                            )
                    );

            // Record the deletion before removing the item.
            boolean historyAdded =
                    addInventoryTransaction(
                            db,
                            id,
                            itemName,
                            -currentQuantity,
                            0,
                            "DELETE",
                            username
                    );

            if (!historyAdded) {
                return false;
            }

            int result =
                    db.delete(
                            INVENTORY_TABLE,
                            "id = ?",
                            new String[]{
                                    String.valueOf(id)
                            }
                    );

            if (result <= 0) {
                return false;
            }

            db.setTransactionSuccessful();

            return true;

        } finally {

            if (cursor != null) {
                cursor.close();
            }

            db.endTransaction();
        }
    }

    // Adds one record to the inventory history table.
    private boolean addInventoryTransaction(
            SQLiteDatabase db,
            Integer inventoryId,
            String itemName,
            int quantityChange,
            int resultingQuantity,
            String transactionType,
            String username
    ) {

        ContentValues values =
                new ContentValues();

        if (inventoryId == null) {

            values.putNull(
                    "inventory_id"
            );

        } else {

            values.put(
                    "inventory_id",
                    inventoryId
            );
        }

        values.put(
                "item_name",
                itemName
        );

        values.put(
                "quantity_change",
                quantityChange
        );

        values.put(
                "resulting_quantity",
                resultingQuantity
        );

        values.put(
                "transaction_type",
                transactionType
        );

        // Avoid storing a null or blank username.
        if (username == null || username.trim().isEmpty()) {

            values.put(
                    "username",
                    "Unknown"
            );

        } else {

            values.put(
                    "username",
                    username
            );
        }

        long result =
                db.insert(
                        TRANSACTION_TABLE,
                        null,
                        values
                );

        return result != -1;
    }

    // Reads the full inventory transaction history.
    public List<InventoryTransaction> getAllInventoryTransactions() {

        List<InventoryTransaction> transactions =
                new ArrayList<>();

        SQLiteDatabase db =
                this.getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT * FROM "
                                + TRANSACTION_TABLE
                                + " ORDER BY timestamp DESC, id DESC",
                        null
                );

        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "id"
                            )
                    );

            int inventoryIdColumn =
                    cursor.getColumnIndexOrThrow(
                            "inventory_id"
                    );

            Integer inventoryId;

            if (cursor.isNull(inventoryIdColumn)) {

                inventoryId = null;

            } else {

                inventoryId =
                        cursor.getInt(
                                inventoryIdColumn
                        );
            }

            String itemName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "item_name"
                            )
                    );

            int quantityChange =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "quantity_change"
                            )
                    );

            int resultingQuantity =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "resulting_quantity"
                            )
                    );

            String transactionType =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "transaction_type"
                            )
                    );

            String username =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "username"
                            )
                    );

            String timestamp =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "timestamp"
                            )
                    );

            InventoryTransaction transaction =
                    new InventoryTransaction(
                            id,
                            inventoryId,
                            itemName,
                            quantityChange,
                            resultingQuantity,
                            transactionType,
                            username,
                            timestamp
                    );

            transactions.add(transaction);
        }

        cursor.close();

        return transactions;
    }
}