package com.example.project2;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class RestockPriorityActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private InventoryAnalyzer inventoryAnalyzer;

    private LinearLayout restockPriorityContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restock_priority);

        databaseHelper = new DatabaseHelper(this);
        inventoryAnalyzer = new InventoryAnalyzer();

        restockPriorityContainer =
                findViewById(R.id.restockPriorityContainer);

        loadRestockPriority();
    }

    // Loads low and out-of-stock items in priority order.
    private void loadRestockPriority() {

        restockPriorityContainer.removeAllViews();

        List<InventoryItem> inventoryItems =
                databaseHelper.getAllInventoryItems();

        List<InventoryItem> priorityItems =
                inventoryAnalyzer.getRestockPriority(inventoryItems);

        if (priorityItems.isEmpty()) {

            TextView emptyText = new TextView(this);

            emptyText.setText("No items currently need restocking.");
            emptyText.setTextSize(16);
            emptyText.setGravity(Gravity.CENTER);
            emptyText.setPadding(12, 24, 12, 24);

            restockPriorityContainer.addView(emptyText);

            return;
        }

        int priorityNumber = 1;

        for (InventoryItem item : priorityItems) {

            TextView priorityText = new TextView(this);

            String status;

            if (item.getQuantity() == 0) {
                status = "OUT OF STOCK";
            } else {
                status = "LOW STOCK";
            }

            priorityText.setText(
                    priorityNumber
                            + ". "
                            + item.getName()
                            + " - Qty "
                            + item.getQuantity()
                            + " - "
                            + status
            );

            priorityText.setTextSize(16);

            priorityText.setPadding(
                    16,
                    16,
                    16,
                    16
            );

            if (item.getQuantity() == 0) {
                priorityText.setTypeface(
                        null,
                        Typeface.BOLD
                );
            }

            priorityText.setBackgroundColor(
                    0xFFFFFFFF
            );

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            params.setMargins(
                    0,
                    0,
                    0,
                    8
            );

            priorityText.setLayoutParams(params);

            restockPriorityContainer.addView(priorityText);

            priorityNumber++;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadRestockPriority();
    }
}