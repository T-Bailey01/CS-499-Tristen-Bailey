package com.example.project2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Main inventory screen for adding, updating, viewing, searching, sorting, and deleting items.
public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private InventoryAnalyzer inventoryAnalyzer;

    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private EditText itemDetailsEditText;
    private EditText searchInventoryEditText;

    private Spinner sortSpinner;

    private TableLayout inventoryTable;

    private TextView totalItemsText;
    private TextView lowStockText;
    private TextView outOfStockText;

    private String selectedSort = "Name A-Z";

    // Stores the user who logged in so database changes can be tracked.
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);
        inventoryAnalyzer = new InventoryAnalyzer();

        // Get the username passed from the SMS permission screen.
        username = getIntent().getStringExtra("username");

        // Use a fallback if the username was not passed for some reason.
        if (username == null || username.trim().isEmpty()) {
            username = "Unknown";
        }

        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        itemDetailsEditText = findViewById(R.id.itemDetailsEditText);
        searchInventoryEditText = findViewById(R.id.searchInventoryEditText);

        sortSpinner = findViewById(R.id.sortSpinner);

        inventoryTable = findViewById(R.id.inventoryTable);

        totalItemsText = findViewById(R.id.totalItemsText);
        lowStockText = findViewById(R.id.lowStockText);
        outOfStockText = findViewById(R.id.outOfStockText);

        Button addItemButton =
                findViewById(R.id.addItemButton);

        Button restockPriorityButton =
                findViewById(R.id.restockPriorityButton);

        Button inventoryHistoryButton =
                findViewById(R.id.inventoryHistoryButton);

        addItemButton.setOnClickListener(
                v -> addItem()
        );

        restockPriorityButton.setOnClickListener(
                v -> {
                    Intent intent =
                            new Intent(
                                    InventoryActivity.this,
                                    RestockPriorityActivity.class
                            );

                    startActivity(intent);
                }
        );

        inventoryHistoryButton.setOnClickListener(
                v -> {
                    Intent intent =
                            new Intent(
                                    InventoryActivity.this,
                                    InventoryHistoryActivity.class
                            );

                    startActivity(intent);
                }
        );

        setupSortSpinner();

        // Refresh the inventory list as the user types in the search box.
        searchInventoryEditText.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after
                    ) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count
                    ) {
                        loadInventoryTable();
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                }
        );

        loadInventoryTable();
    }

    // Sets up the different ways the inventory can be sorted.
    private void setupSortSpinner() {

        String[] sortOptions = {
                "Name A-Z",
                "Quantity Low to High",
                "Quantity High to Low"
        };

        ArrayAdapter<String> sortAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        sortOptions
                );

        sortAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        sortSpinner.setAdapter(sortAdapter);

        sortSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {

                        selectedSort = sortOptions[position];

                        loadInventoryTable();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                    }
                }
        );
    }

    // Gets the entered item info and adds it to the database.
    private void addItem() {

        String itemName =
                itemNameEditText.getText().toString().trim();

        String quantityText =
                itemQuantityEditText.getText().toString().trim();

        String details =
                itemDetailsEditText.getText().toString().trim();

        // Make sure the item has a name and quantity.
        if (!InventoryValidator.isValidName(itemName)
                || quantityText.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter a valid item name and quantity.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int quantity;

        // Quantity needs to be a whole number.
        try {

            quantity = Integer.parseInt(quantityText);

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Quantity must be a number.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Do not allow inventory to start below zero.
        if (!InventoryValidator.isValidQuantity(quantity)) {

            Toast.makeText(
                    this,
                    "Quantity cannot be below zero.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean added =
                databaseHelper.addInventoryItem(
                        itemName,
                        quantity,
                        details,
                        username
                );

        if (added) {

            Toast.makeText(
                    this,
                    "Item added.",
                    Toast.LENGTH_SHORT
            ).show();

            clearInputFields();

            // Send an alert if the item was added with no stock.
            if (quantity == 0) {
                sendLowInventorySms(itemName);
            }

            loadInventoryTable();

        } else {

            Toast.makeText(
                    this,
                    "Item could not be added.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Clears the item fields after something is added.
    private void clearInputFields() {

        itemNameEditText.setText("");
        itemQuantityEditText.setText("");
        itemDetailsEditText.setText("");
    }

    // Reloads the inventory table with the latest items.
    private void loadInventoryTable() {

        inventoryTable.removeAllViews();

        addHeaderRow();

        List<InventoryItem> inventoryItems =
                databaseHelper.getAllInventoryItems();

        // Keep the summary based on the full inventory.
        updateInventorySummary(inventoryItems);

        String searchText =
                searchInventoryEditText
                        .getText()
                        .toString()
                        .trim()
                        .toLowerCase(Locale.ROOT);

        List<InventoryItem> filteredItems =
                filterInventory(
                        inventoryItems,
                        searchText
                );

        // Sort the filtered results using the option selected by the user.
        filteredItems =
                applySelectedSort(filteredItems);

        // Show a message if there is nothing to display.
        if (filteredItems.isEmpty()) {

            TableRow emptyRow =
                    new TableRow(this);

            TextView emptyText =
                    new TextView(this);

            if (searchText.isEmpty()) {

                emptyText.setText(
                        "No inventory items yet."
                );

            } else {

                emptyText.setText(
                        "No matching inventory items."
                );
            }

            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);

            emptyText.setPadding(
                    8,
                    20,
                    8,
                    20
            );

            TableRow.LayoutParams emptyParams =
                    new TableRow.LayoutParams(
                            TableRow.LayoutParams.MATCH_PARENT,
                            TableRow.LayoutParams.WRAP_CONTENT
                    );

            emptyText.setLayoutParams(emptyParams);

            emptyRow.addView(emptyText);

            inventoryTable.addView(emptyRow);

            return;
        }

        // Build one table row for each matching inventory item.
        for (InventoryItem item : filteredItems) {

            int id = item.getId();
            String itemName = item.getName();
            int quantity = item.getQuantity();

            String status =
                    getInventoryStatus(quantity);

            TableRow row =
                    new TableRow(this);

            row.setGravity(
                    Gravity.CENTER_VERTICAL
            );

            TextView itemCell =
                    makeCell(
                            itemName,
                            2.4f
                    );

            TextView quantityCell =
                    makeCell(
                            String.valueOf(quantity),
                            0.8f
                    );

            TextView statusCell =
                    makeCell(
                            status,
                            1.1f
                    );

            Button decreaseButton =
                    makeSmallButton(
                            "-",
                            0.7f
                    );

            decreaseButton.setOnClickListener(
                    v -> changeQuantity(
                            id,
                            itemName,
                            quantity - 1
                    )
            );

            Button increaseButton =
                    makeSmallButton(
                            "+",
                            0.7f
                    );

            increaseButton.setOnClickListener(
                    v -> changeQuantity(
                            id,
                            itemName,
                            quantity + 1
                    )
            );

            Button deleteButton =
                    makeSmallButton(
                            "Del",
                            1.0f
                    );

            deleteButton.setOnClickListener(
                    v -> deleteItem(id)
            );

            row.addView(itemCell);
            row.addView(quantityCell);
            row.addView(statusCell);
            row.addView(decreaseButton);
            row.addView(increaseButton);
            row.addView(deleteButton);

            inventoryTable.addView(row);
        }
    }

    // Filters the inventory list using the item name.
    private List<InventoryItem> filterInventory(
            List<InventoryItem> inventoryItems,
            String searchText
    ) {

        List<InventoryItem> filteredItems =
                new ArrayList<>();

        // An empty search should show everything.
        if (searchText.isEmpty()) {

            filteredItems.addAll(
                    inventoryItems
            );

            return filteredItems;
        }

        for (InventoryItem item : inventoryItems) {

            String itemName =
                    item.getName()
                            .toLowerCase(Locale.ROOT);

            if (itemName.contains(searchText)) {

                filteredItems.add(item);
            }
        }

        return filteredItems;
    }

    // Applies the sorting option selected by the user.
    private List<InventoryItem> applySelectedSort(
            List<InventoryItem> items
    ) {

        switch (selectedSort) {

            case "Quantity Low to High":

                return inventoryAnalyzer
                        .sortByQuantityLowToHigh(items);

            case "Quantity High to Low":

                return inventoryAnalyzer
                        .sortByQuantityHighToLow(items);

            case "Name A-Z":

            default:

                return inventoryAnalyzer
                        .sortByName(items);
        }
    }

    // Updates the numbers shown at the top of the screen.
    private void updateInventorySummary(
            List<InventoryItem> inventoryItems
    ) {

        int totalItems =
                inventoryItems.size();

        int lowStock = 0;
        int outOfStock = 0;

        for (InventoryItem item : inventoryItems) {

            int quantity =
                    item.getQuantity();

            if (quantity == 0) {

                outOfStock++;

            } else if (quantity <= 10) {

                lowStock++;
            }
        }

        totalItemsText.setText(
                String.valueOf(totalItems)
        );

        lowStockText.setText(
                String.valueOf(lowStock)
        );

        outOfStockText.setText(
                String.valueOf(outOfStock)
        );
    }

    // Gives an item its basic stock status.
    private String getInventoryStatus(
            int quantity
    ) {

        if (quantity == 0) {
            return "Out";
        }

        if (quantity <= 10) {
            return "Low";
        }

        return "In";
    }

    // Adds the labels at the top of the inventory table.
    private void addHeaderRow() {

        TableRow headerRow =
                new TableRow(this);

        headerRow.addView(
                makeHeaderCell(
                        "Item",
                        2.4f
                )
        );

        headerRow.addView(
                makeHeaderCell(
                        "Qty",
                        0.8f
                )
        );

        headerRow.addView(
                makeHeaderCell(
                        "Status",
                        1.1f
                )
        );

        headerRow.addView(
                makeHeaderCell(
                        "-",
                        0.7f
                )
        );

        headerRow.addView(
                makeHeaderCell(
                        "+",
                        0.7f
                )
        );

        headerRow.addView(
                makeHeaderCell(
                        "Del",
                        1.0f
                )
        );

        inventoryTable.addView(
                headerRow
        );
    }

    // Changes the quantity without letting it go below zero.
    private void changeQuantity(
            int id,
            String itemName,
            int newQuantity
    ) {

        if (!InventoryValidator.isValidQuantity(newQuantity)) {

            Toast.makeText(
                    this,
                    "Quantity cannot be below zero.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean updated =
                databaseHelper.updateQuantity(
                        id,
                        newQuantity,
                        username
                );

        if (updated) {

            // Alert the user when the item reaches zero.
            if (newQuantity == 0) {
                sendLowInventorySms(itemName);
            }

            loadInventoryTable();

        } else {

            Toast.makeText(
                    this,
                    "Quantity could not be updated.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Deletes an item and then refreshes the table.
    private void deleteItem(int id) {

        boolean deleted =
                databaseHelper.deleteInventoryItem(
                        id,
                        username
                );

        if (deleted) {

            Toast.makeText(
                    this,
                    "Item deleted.",
                    Toast.LENGTH_SHORT
            ).show();

            loadInventoryTable();

        } else {

            Toast.makeText(
                    this,
                    "Item could not be deleted.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Sends a message when an item reaches zero if SMS alerts are enabled.
    private void sendLowInventorySms(
            String itemName
    ) {

        SharedPreferences preferences =
                getSharedPreferences(
                        "sms_settings",
                        MODE_PRIVATE
                );

        boolean smsEnabled =
                preferences.getBoolean(
                        "sms_enabled",
                        false
                );

        String phoneNumber =
                preferences.getString(
                        "phone_number",
                        ""
                );

        if (!smsEnabled
                || phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    itemName
                            + " is out of stock. SMS alerts are off.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            SmsManager smsManager =
                    SmsManager.getDefault();

            try {

                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        "IVTRK Alert: "
                                + itemName
                                + " has reached 0 and may need to be restocked.",
                        null,
                        null
                );

                Toast.makeText(
                        this,
                        "SMS alert sent for "
                                + itemName
                                + ".",
                        Toast.LENGTH_SHORT
                ).show();

            } catch (Exception e) {

                Toast.makeText(
                        this,
                        "SMS alert could not be sent.",
                        Toast.LENGTH_LONG
                ).show();
            }

        } else {

            Toast.makeText(
                    this,
                    itemName
                            + " is out of stock. SMS permission was not granted.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Makes one table cell and gives it part of the available screen width.
    private TextView makeCell(
            String text,
            float weight
    ) {

        TextView cell =
                new TextView(this);

        cell.setText(text);
        cell.setTextSize(14);
        cell.setGravity(Gravity.CENTER);

        cell.setPadding(
                4,
                12,
                4,
                12
        );

        cell.setSingleLine(true);

        cell.setEllipsize(
                TextUtils.TruncateAt.END
        );

        TableRow.LayoutParams params =
                new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        weight
                );

        cell.setLayoutParams(params);

        return cell;
    }

    // Makes the bold cells used for the table headers.
    private TextView makeHeaderCell(
            String text,
            float weight
    ) {

        TextView cell =
                makeCell(
                        text,
                        weight
                );

        cell.setTypeface(
                null,
                Typeface.BOLD
        );

        cell.setTextColor(
                0xFF1F3A5F
        );

        return cell;
    }

    // Makes one of the small inventory row buttons.
    private Button makeSmallButton(
            String text,
            float weight
    ) {

        Button button =
                new Button(this);

        button.setText(text);
        button.setTextSize(10);

        button.setMinWidth(0);
        button.setMinimumWidth(0);

        button.setMinHeight(0);
        button.setMinimumHeight(0);

        button.setPadding(
                0,
                4,
                0,
                4
        );

        TableRow.LayoutParams params =
                new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        weight
                );

        params.setMargins(
                2,
                4,
                2,
                4
        );

        button.setLayoutParams(params);

        return button;
    }
}