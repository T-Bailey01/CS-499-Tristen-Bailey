package com.example.project2;

public class InventoryItem {

    private int id;
    private String name;
    private int quantity;
    private String details;

    public InventoryItem(int id, String name, int quantity, String details) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.details = details;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDetails() {
        return details;
    }
}