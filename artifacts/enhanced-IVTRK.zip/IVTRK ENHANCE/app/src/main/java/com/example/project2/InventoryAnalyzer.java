package com.example.project2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class InventoryAnalyzer {

    // Returns a copy of the inventory sorted alphabetically by item name.
    public List<InventoryItem> sortByName(List<InventoryItem> items) {

        List<InventoryItem> sortedItems =
                new ArrayList<>(items);

        sortedItems.sort(
                Comparator.comparing(
                        InventoryItem::getName,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        return sortedItems;
    }

    // Returns a copy of the inventory sorted from lowest quantity to highest.
    public List<InventoryItem> sortByQuantityLowToHigh(
            List<InventoryItem> items
    ) {

        List<InventoryItem> sortedItems =
                new ArrayList<>(items);

        sortedItems.sort(
                Comparator.comparingInt(
                        InventoryItem::getQuantity
                )
        );

        return sortedItems;
    }

    // Returns a copy of the inventory sorted from highest quantity to lowest.
    public List<InventoryItem> sortByQuantityHighToLow(
            List<InventoryItem> items
    ) {

        List<InventoryItem> sortedItems =
                new ArrayList<>(items);

        sortedItems.sort(
                Comparator.comparingInt(
                        InventoryItem::getQuantity
                ).reversed()
        );

        return sortedItems;
    }

    // Groups inventory into Out, Low, and In stock categories.
    public Map<String, List<InventoryItem>> groupByStockStatus(
            List<InventoryItem> items
    ) {

        Map<String, List<InventoryItem>> groupedItems =
                new HashMap<>();

        groupedItems.put(
                "Out",
                new ArrayList<>()
        );

        groupedItems.put(
                "Low",
                new ArrayList<>()
        );

        groupedItems.put(
                "In",
                new ArrayList<>()
        );

        for (InventoryItem item : items) {

            int quantity =
                    item.getQuantity();

            if (quantity == 0) {

                groupedItems
                        .get("Out")
                        .add(item);

            } else if (quantity <= 10) {

                groupedItems
                        .get("Low")
                        .add(item);

            } else {

                groupedItems
                        .get("In")
                        .add(item);
            }
        }

        return groupedItems;
    }

    // Builds a priority list with the lowest stock items first.
    public List<InventoryItem> getRestockPriority(
            List<InventoryItem> items
    ) {

        PriorityQueue<InventoryItem> priorityQueue =
                new PriorityQueue<>(
                        Comparator.comparingInt(
                                InventoryItem::getQuantity
                        )
                );

        for (InventoryItem item : items) {

            if (item.getQuantity() <= 10) {

                priorityQueue.offer(item);
            }
        }

        List<InventoryItem> priorityList =
                new ArrayList<>();

        while (!priorityQueue.isEmpty()) {

            priorityList.add(
                    priorityQueue.poll()
            );
        }

        return priorityList;
    }
}