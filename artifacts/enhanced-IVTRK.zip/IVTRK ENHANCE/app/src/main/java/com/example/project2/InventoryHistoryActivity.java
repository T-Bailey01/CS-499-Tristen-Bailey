package com.example.project2;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

// Shows the inventory changes stored in the transaction history table.
public class InventoryHistoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private LinearLayout historyContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_history);

        databaseHelper = new DatabaseHelper(this);

        historyContainer =
                findViewById(R.id.historyContainer);

        loadInventoryHistory();
    }

    // Loads the newest inventory transactions first.
    private void loadInventoryHistory() {

        historyContainer.removeAllViews();

        List<InventoryTransaction> transactions =
                databaseHelper.getAllInventoryTransactions();

        if (transactions.isEmpty()) {

            TextView emptyText =
                    new TextView(this);

            emptyText.setText(
                    "No inventory history has been recorded yet."
            );

            emptyText.setTextSize(16);
            emptyText.setGravity(Gravity.CENTER);

            emptyText.setPadding(
                    12,
                    24,
                    12,
                    24
            );

            historyContainer.addView(emptyText);

            return;
        }

        for (InventoryTransaction transaction : transactions) {

            LinearLayout historyCard =
                    new LinearLayout(this);

            historyCard.setOrientation(
                    LinearLayout.VERTICAL
            );

            historyCard.setPadding(
                    16,
                    14,
                    16,
                    14
            );

            historyCard.setBackgroundColor(
                    0xFFFFFFFF
            );

            TextView itemNameText =
                    new TextView(this);

            itemNameText.setText(
                    transaction.getItemName()
            );

            itemNameText.setTextSize(17);

            itemNameText.setTypeface(
                    null,
                    Typeface.BOLD
            );

            itemNameText.setTextColor(
                    0xFF1F3A5F
            );

            TextView actionText =
                    new TextView(this);

            actionText.setText(
                    buildActionText(transaction)
            );

            actionText.setTextSize(14);

            actionText.setPadding(
                    0,
                    4,
                    0,
                    2
            );

            TextView userText =
                    new TextView(this);

            userText.setText(
                    "User: " + transaction.getUsername()
            );

            userText.setTextSize(13);

            userText.setTextColor(
                    0xFF455A64
            );

            userText.setPadding(
                    0,
                    2,
                    0,
                    2
            );

            TextView dateText =
                    new TextView(this);

            dateText.setText(
                    transaction.getTimestamp()
            );

            dateText.setTextSize(12);

            dateText.setTextColor(
                    0xFF607D8B
            );

            historyCard.addView(itemNameText);
            historyCard.addView(actionText);
            historyCard.addView(userText);
            historyCard.addView(dateText);

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            params.setMargins(
                    0,
                    0,
                    0,
                    10
            );

            historyCard.setLayoutParams(params);

            historyContainer.addView(historyCard);
        }
    }

    // Builds readable text for each type of inventory transaction.
    private String buildActionText(
            InventoryTransaction transaction
    ) {

        String type =
                transaction.getTransactionType();

        int change =
                transaction.getQuantityChange();

        int resultingQuantity =
                transaction.getResultingQuantity();

        switch (type) {

            case "ADD":

                return "Added with quantity "
                        + resultingQuantity;

            case "INCREASE":

                return "Increased by "
                        + change
                        + " → New quantity: "
                        + resultingQuantity;

            case "DECREASE":

                return "Decreased by "
                        + Math.abs(change)
                        + " → New quantity: "
                        + resultingQuantity;

            case "DELETE":

                return "Item deleted from inventory";

            default:

                return type
                        + " → Quantity: "
                        + resultingQuantity;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadInventoryHistory();
    }
}