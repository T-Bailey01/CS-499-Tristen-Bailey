package com.example.project2;

// Represents one recorded inventory change.
public class InventoryTransaction {

    private int id;
    private Integer inventoryId;
    private String itemName;
    private int quantityChange;
    private int resultingQuantity;
    private String transactionType;
    private String username;
    private String timestamp;

    public InventoryTransaction(
            int id,
            Integer inventoryId,
            String itemName,
            int quantityChange,
            int resultingQuantity,
            String transactionType,
            String username,
            String timestamp
    ) {
        this.id = id;
        this.inventoryId = inventoryId;
        this.itemName = itemName;
        this.quantityChange = quantityChange;
        this.resultingQuantity = resultingQuantity;
        this.transactionType = transactionType;
        this.username = username;
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public Integer getInventoryId() {
        return inventoryId;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantityChange() {
        return quantityChange;
    }

    public int getResultingQuantity() {
        return resultingQuantity;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public String getUsername() {
        return username;
    }

    public String getTimestamp() {
        return timestamp;
    }
}